import matplotlib.pyplot as plt
import numpy as np
from django.shortcuts import render

import requests

def display(request):
    x = np.arange(1, 30)
    y = np.arange(31, 60)
    # plt.xticks(range(len(duration_dict)), list(duration_dict.keys()))
    # plt.bar(range(len(duration_dict)), duration_dict.values(), align='center')
    plt.plot(x, y)
    plt.savefig('testing_figsave2.png')
    return render(request, "testing_figsave2.png")


