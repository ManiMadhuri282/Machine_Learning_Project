from django.shortcuts import render
from django.views.generic import TemplateView, ListView
import requests
import json
import datetime
import random


def speaker(request):
    return render(request, "speaker.html")


def speakerOnOff(request):
    """
    This function allows a user to turn a speaker on or off and returns the updated status.
    """
    # Get the current date time group (DTG) of the user's request
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(now)

    # Get the current status of the speaker before changing the status requested by user.
    speaker_OnOff_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/on_off.json'
    speaker_vol_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/volume.json'
    speaker_PlayStop_url ='https://inf551-iot.firebaseio.com/speaker/current_state/play_stop.json'
    speaker_currentSong_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/song.json'
    old_state_vol = requests.get(speaker_vol_url)
    old_state_OnOff = requests.get(speaker_OnOff_url)
    old_state_PlayStop = requests.get(speaker_PlayStop_url)
    old_state_song = requests.get(speaker_currentSong_url)
    print(old_state_vol.text)
    print(old_state_OnOff.text)
    print(old_state_PlayStop)
    print(old_state_song)

    # Save the current status in a dictionary in order to save the record in the database.
    old_state_vol =  old_state_vol.text
    old_state_OnOff = old_state_OnOff.text
    old_state_PlayStop = old_state_PlayStop.text
    old_state_song = old_state_song.text
    speaker_past_record_dict = {}
    speaker_past_record_dict[str(now)]= {"volume" :int(old_state_vol),
                                         "on_off" :int(old_state_OnOff),
                                         "play_stop": int(old_state_PlayStop),
                                         "song":old_state_song}
    print(speaker_past_record_dict)

    # Post the current status of the bulb to save the record for later statistics.
    speaker_records_url = 'https://inf551-iot.firebaseio.com/speaker/records.json'
    speaker_post = requests.patch(speaker_records_url, json.dumps(speaker_past_record_dict))

    # Now that we have saved the current status in a record, change the status based on the user's request.
    if old_state_OnOff == str(1):
        new_state_OnOff = str(0)
        speaker_status_PlayStop = requests.put(speaker_PlayStop_url, json.dumps(0))
    else:
        new_state_OnOff = str(1)

    # Post the new status of the speaker to the database.
    speaker_status_OnOff = requests.put(speaker_OnOff_url, json.dumps(int(new_state_OnOff)))

    # Return the updated status to the user
    return render(request, 'speaker.html', {'speaker_on_off': new_state_OnOff})


def speakerVolume(request):
    """
    This function allows a user to change the volume of the speaker.
    Does not need to save a record
    """
    # Get the current status of the speaker volume before changing the status requested by user.
    speaker_vol_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/volume.json'
    new_state_volume = request.POST.get('new_state')
    print("new state volume type")
    print(type(new_state_volume))
    print("new state volume")
    print(new_state_volume)
    speaker_status_volume = requests.put(speaker_vol_url, json.dumps(int(new_state_volume)))




    return render(request, 'speaker.html', {'speaker_vol': new_state_volume})









def speakerPlayStop(request):
    """
    This function allows a user to play or stop music stored on the speaker.
    Does not need to save a record
    """
    # Get the current date time group (DTG) of the user's request
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(now)

    # Get the current status of the speaker's play/stop status.
    speaker_OnOff_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/on_off.json'
    speaker_vol_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/volume.json'
    speaker_PlayStop_url ='https://inf551-iot.firebaseio.com/speaker/current_state/play_stop.json'
    speaker_currentSong_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/song.json'
    old_state_vol = requests.get(speaker_vol_url)
    old_state_OnOff = requests.get(speaker_OnOff_url)
    old_state_PlayStop = requests.get(speaker_PlayStop_url)
    old_state_song = requests.get(speaker_currentSong_url)
    print(old_state_vol.text)
    print(old_state_OnOff.text)
    print(old_state_PlayStop.text)
    print(old_state_song.text)

    # Save the current status in a dictionary in order to save the record in the database.
    old_state_vol = old_state_vol.text
    old_state_OnOff = old_state_OnOff.text
    old_state_PlayStop = old_state_PlayStop.text
    old_state_song = old_state_song.text
    speaker_past_record_dict = {}
    speaker_past_record_dict[str(now)] = {"volume": int(old_state_vol),
                                          "on_off": int(old_state_OnOff),
                                          "play_stop": int(old_state_PlayStop),
                                          "song": old_state_song}
    print(speaker_past_record_dict)

    # Post the current status of the speaker to save the record for later statistics.
    speaker_records_url = 'https://inf551-iot.firebaseio.com/speaker/records.json'
    speaker_post = requests.patch(speaker_records_url, json.dumps(speaker_past_record_dict))

    # Now that we have saved the current status, change the status of the speaker's play/stop function
    if old_state_PlayStop == str(1):
        new_state_PlayStop = str(0) # Stop playing music

        # Post the new status to the database.
        speaker_status_PlayStop = requests.put(speaker_PlayStop_url, json.dumps(int(new_state_PlayStop)))

        # Return the updated status to the user
        return render(request, 'speaker.html', {'speaker_PlayStop': new_state_PlayStop})
    else:
        if old_state_OnOff == str(0): # Check if the speaker is off
            new_state_OnOff = str(1) # Turn the speaker on if it was off
            speaker_status_OnOff = requests.put(speaker_OnOff_url, json.dumps(int(new_state_OnOff)))

        # Play the song listed in the current state
        print(old_state_song)
        new_state_PlayStop = str(1)  # Start playing music

        # Post the new status to the database.
        speaker_status_PlayStop = requests.put(speaker_PlayStop_url, json.dumps(int(new_state_PlayStop)))

        # Return the updated status to the user
        return render(request, 'speaker.html', {'speaker_PlayStop': new_state_PlayStop,
                                             'speaker_song':old_state_song})


def speakerFwd(request):
    """
    This function allows a user to look for a new song to play.
    """
    # Get the song in the current state.
    speaker_currentSong_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/song.json'
    current_state_song = requests.get(speaker_currentSong_url)

    # Get the list of songs stored in the database and shuffle the list
    songlist_url = 'https://inf551-iot.firebaseio.com/speaker/songlist.json'
    songlist = requests.get(songlist_url)
    songlist_dict = songlist.json()
    songlist_list=[]
    for key, value in songlist_dict.items():
        song = str(key) + " - " + str(value)
        songlist_list.append(song)
    random.shuffle(songlist_list)

    # Get the most recent list of songs played
    songsPlayed_url = 'https://inf551-iot.firebaseio.com/speaker/songs_played.json'
    songsPlayed = requests.get(songsPlayed_url)
    songsPlayed_list=songsPlayed.json()

    # If the speakers are playing music, save the song to the list of songs played
    speaker_PlayStop_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/play_stop.json'
    current_state_PlayStop = requests.get(speaker_PlayStop_url)
    current_state_PlayStop = current_state_PlayStop.text
    if current_state_PlayStop == str(1):
        songsPlayed_list.append(current_state_song.json())
    print(songsPlayed_list)

    # Update the list of recently played songs
    songsPlayed_post = requests.put(songsPlayed_url, json.dumps(songsPlayed_list))

    # Show the next shuffled song ready to play
    current_song = requests.put(speaker_currentSong_url, json.dumps(songlist_list[0]))
    return render(request, 'speaker.html', {'speaker_fwd': songlist_list[0]})

def speakerBack(request):
    """
    This function allows a user to play the last played song in the list of most recently played songs.
    """
    # Get the list of songs that have been recently played
    songsPlayed_url = 'https://inf551-iot.firebaseio.com/speaker/songs_played.json'
    songsPlayed = requests.get(songsPlayed_url)
    songsPlayed_list=songsPlayed.json()
    lastPlayedSong = songsPlayed_list[-1] # Get the last played song
    songsPlayed_list.pop() # Remove the last played song

    # Update the list of most recently played songs
    songsPlayed_post = requests.put(songsPlayed_url, json.dumps(songsPlayed_list))
    print(songsPlayed_list)

    # Show/Play the last played song
    speaker_currentSong_url = 'https://inf551-iot.firebaseio.com/speaker/current_state/song.json'
    current_song = requests.put(speaker_currentSong_url, json.dumps(lastPlayedSong))
    return render(request, 'speaker.html', {'speaker_back': lastPlayedSong})


def speakerStats(request):

    # Get all of the records for the speaker
    speaker_records_url = 'https://inf551-iot.firebaseio.com/speaker/records.json'
    speaker_records = requests.get(speaker_records_url)
    speaker_records_dict = speaker_records.json()

    # Modify the records by selecting only the "on_off" state to calculate the stats
    speaker_records_mod = {}
    for key, value in speaker_records_dict.items():
        speaker_records_mod[key] = speaker_records_dict[key]['on_off']

    # Initialize values to that will be used for calculating the stats
    duration_dict = {}
    duration_by_month = {}
    len_speaker_records = len(speaker_records_mod)
    length = 1

    # Calculate the stats for the speaker
    for key, value in speaker_records_mod.items():

        # If at the end of the records and the last value is 0, break
        if length == len_speaker_records and value == 0:
            break
        elif length == 1:
            if value == 1:
                former_state = 0
            elif value == 0:
                former_state = 1
            length += 1
        else:
            length += 1

        # Determine all the current values of the iteration
        dtg_string = key
        dtg = datetime.datetime.fromisoformat(dtg_string)
        current_day = dtg.day
        current_month = dtg.month

        # Calculate the time in minutes the device was on for each day
        if value == 0 and former_state == 1:  # device was turned on if the saved value was 0 because it was previously off
            start_key = key
            start = dtg  # start the timer
            start_day = dtg.day
            start_month = dtg.month
            duration_for_day = 0
            former_state = 0
        elif value == 0 and former_state == 0:  # device remained on
            pass
        elif value == 1 and former_state == 1:  # device remained off
            pass
        else:  # device turned off
            end_ket = key
            end = dtg  # stop the timer
            end_day = dtg.day
            former_state = 1

            # Determine the amount of time in mins the device was turned on
            duration = (end - start)  # get the difference in time
            duration_in_s = duration.total_seconds()  # convert duration to seconds
            mins = divmod(duration_in_s, 60)[0]  # convert duration to minutes

            # If the time period is within the same day, update and save the num of mins the device was on
            if start_day == end_day:
                duration_for_day += mins
                if start_day in duration_dict:
                    duration_for_day += duration_dict[start_day]
                    duration_dict[start_day] = duration_for_day
                else:
                    duration_dict[start_day] = duration_for_day

            # If the time period spans more than 1 day, determine the num of mins the device was on for each day
            elif start_day != end_day:
                end_temp = start.replace(hour=23, minute=59, second=59)  # set the temporary end dtg
                duration_temp = (end_temp - start).total_seconds()  # find the duration in seconds
                mins_temp = divmod(duration_temp, 60)[0]  # convert duration to minutes
                duration_for_day += mins_temp

                if start_day in duration_dict:  # if the day is already in the dictionary, update the values
                    duration_for_day += duration_dict[start_day]
                    duration_dict[start_day] = duration_for_day
                else:  # if the day is not in the dictionary, add the value
                    duration_dict[start_day] = duration_for_day

                while True:
                    # go to the next day
                    if current_month == 1 or 3 or 5 or 7 or 8 or 10 or 12:
                        max_day = 31
                    elif current_month == 2:
                        max_day = 28
                    else:
                        max_day = 30

                    if start_day < max_day:
                        start_day += 1
                    else:
                        start_day = 1
                        start_month += 1
                        duration_dict = {}  # clear the records for the month

                    # Update the start date to properly calculate the time period
                    start = start.replace(month=start_month, day=start_day, hour=0, minute=0, second=0)

                    if start_day == end_day:
                        duration = (end - start).total_seconds()  # get the druation in seconds
                        mins = divmod(duration, 60)[0]  # convert duration to minutes
                        duration_for_day = mins
                        duration_dict[start_day] = duration_for_day
                        break
                    elif start_day != end_day:
                        duration_dict[start_day] = 1440  # this means the device was on the entire day
        duration_by_month[start_month] = duration_dict

    return render(request, 'speaker.html', {'speaker_stats': duration_by_month})



def speakerStatus(request):
    """
    This function allows a user to get the current status of a speaker.
    """
    # Get the current status of the plug from the cloud database
    speaker_status = requests.get("https://inf551-iot.firebaseio.com/speaker/current_state/on_off.json")

    # Print the status of the speaker in the command line
    print(speaker_status.text)

    # Return the status of the speaker to the user
    speaker_status = speaker_status.text
    return render(request, 'speaker.html', {'speaker_status':speaker_status})
