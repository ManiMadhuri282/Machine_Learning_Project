from django import template
from django.shortcuts import render
from django.views.generic import TemplateView, ListView
import requests
import json
import datetime
import numpy as np
import matplotlib.pyplot as plt
import random
#import pyrebase

register = template.Library()



def bulbDimmer(dimmer_value):

    """

    This function allows a user to interact with the bulb's dimmer and returns the updated status.

    # Get the current date time group (DTG) of the user's request
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(now)

    # Get the current status of the bulb before changing the status requested by user.
    bulb_OnOff_url = 'https://inf551-iot.firebaseio.com/bulb/current_state/on_off.json'
    bulb_dimmer_url = 'https://inf551-iot.firebaseio.com/bulb/current_state/dimmer.json'
    old_state_dimmer = requests.get(bulb_dimmer_url)
    old_state_OnOff = requests.get(bulb_OnOff_url)
    print(old_state_dimmer.text)
    print(old_state_OnOff.text)

    # Save the current status in a dictionary in order to save the record in the database.
    old_state_dimmer =  old_state_dimmer.text
    old_state_OnOff = old_state_OnOff.text
    bulb_past_record_dict = {}
    bulb_past_record_dict[str(now)]= {"dimmer" :int(old_state_dimmer),"on_off" :int(old_state_OnOff) }
    print(bulb_past_record_dict)

    # Post the current status of the bulb to save the record for later statistics.
    bulb_records_url = 'https://inf551-iot.firebaseio.com/bulb/records.json'
    bulb_post = requests.patch(bulb_records_url, json.dumps(bulb_past_record_dict))
    """
    # Now that we have saved the current status in a record, change the status based on the user's request.
    """
    if old_state_OnOff == str(1):
        new_state_OnOff = str(0)
    else:
        new_state_OnOff = str(1)
    """
    new_state_dimmer = dimmer_value
    #new_state_dimmer = request.POST.get('data')
    print(type(new_state_dimmer))
    print(new_state_dimmer)
    #database.child('bulb').child('current_state').child('dimmer').set(new_state_dimmer)
    # Post the new status of the dimmer to the database.
    bulb_dimmer_url = 'https://inf551-iot.firebaseio.com/bulb/current_state/dimmer.json'
    #bulb_status_dimmer = requests.put(bulb_dimmer_url, json.dumps(int(new_state_dimmer.value)))

    # Return the updated status to the user
    #return render('bulb.html', {'bulb_dimmer': new_state_dimmer})

register.filter('bulbDimmer', bulbDimmer )