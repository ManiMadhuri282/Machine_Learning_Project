from django.shortcuts import render
from django.views.generic import TemplateView, ListView
import requests
import json
import datetime
import random


def home(request):
    return render(request, "home.html")

class htmlBulbC(TemplateView):
    template_name = 'statisticsBulbCurrent.html'

class htmlBulbP(TemplateView):
    template_name = 'statisticsBulbPrevious.html'

class htmlPlugC(TemplateView):
    template_name = 'statisticsPlugCurrent.html'

class htmlPlugP(TemplateView):
    template_name = 'statisticsPlugPrevious.html'

class htmlSpeakerC(TemplateView):
    template_name = 'statisticsSpeakerCurrent.html'

class htmlSpeakerP(TemplateView):
    template_name = 'statisticsSpeakerPrevious.html'


class speakerApp(TemplateView):
    template_name = 'speaker.html'

class bulbApp(TemplateView):
    template_name = 'bulb.html'