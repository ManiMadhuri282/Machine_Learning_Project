
""" using same plot object is causing QCoreApplication dangling reference error"""

from PIL import Image
""" the PIL library converts the graph as static content to be sent to the html """
from io import BytesIO
from django.http import HttpResponse
import requests
import json
import datetime
import random
import numpy as np


def statsValues(dictionary):
    days=[]
    mins=[]
    for key,value in dictionary.items():
        days.append(key)
        mins.append(value)
    return days, mins



def bulbStats():
    """
    This function obtains all the current usage statistics for the bulb.
    """
    # Get all of the records for the bulb
    bulb_records_url = 'https://inf551-iot.firebaseio.com/bulb/records.json'
    bulb_records = requests.get(bulb_records_url)
    bulb_records_dict = bulb_records.json()

    # Modify the records by selecting only the "on_off" state to calculate the stats
    bulb_records_mod = {}
    for key, value in bulb_records_dict.items():
        bulb_records_mod[key] = bulb_records_dict[key]['on_off']

    # Initialize values to that will be used for calculating the stats
    duration_dict = {}
    duration_by_month = {}
    len_bulb_records = len(bulb_records_mod)
    length = 1
    former_month = None

    # Calculate the stats for the bulb
    for key, value in bulb_records_mod.items():

        # If at the end of the records and the last value is 0, break
        if length == len_bulb_records and value == 0:
            break
        elif length == 1:
            if value == 1:
                former_state = 0
            elif value == 0:
                former_state = 1
            length += 1
        else:
            length += 1

        # Determine all the current values of the iteration
        dtg_string = key
        dtg = datetime.datetime.fromisoformat(dtg_string)
        current_day = dtg.day
        current_month = dtg.month

        # Calculate the time in minutes the device was on for each day
        if value == 0 and former_state == 1:  # device was turned on if the saved value was 0 because it was previously off
            start_key = key
            start = dtg  # start the timer
            start_day = dtg.day
            start_month = dtg.month
            duration_for_day = 0
            former_state = 0
        elif value == 0 and former_state == 0:  # device remained on
            pass
        elif value == 1 and former_state == 1:  # device remained off
            pass
        else:  # device turned off
            end_key = key
            end = dtg  # stop the timer
            end_day = dtg.day
            former_state = 1

            # Determine the amount of time in mins the device was turned on
            duration = (end - start)  # get the difference in time
            duration_in_s = duration.total_seconds()  # convert duration to seconds
            mins = divmod(duration_in_s, 60)[0]  # convert duration to minutes

            # If the time period is within the same day, update and save the num of mins the device was on
            if start_day == end_day:
                duration_for_day += mins
                if start_day in duration_dict:
                    duration_for_day += duration_dict[start_day]
                    duration_dict[start_day] = duration_for_day
                    former_month = current_month
                    print("former status6".format(former_month))
                else:
                    duration_dict[start_day] = duration_for_day
                    former_month = current_month
                    print("former status7".format(former_month))

            # If the time period spans more than 1 day, determine the num of mins the device was on for each day
            elif start_day != end_day:
                end_temp = start.replace(hour=23, minute=59, second=59)  # set the temporary end dtg
                duration_temp = (end_temp - start).total_seconds()  # find the duration in seconds
                mins_temp = divmod(duration_temp, 60)[0]  # convert duration to minutes
                duration_for_day += mins_temp

                if start_day in duration_dict:  # if the day is already in the dictionary, update the values
                    duration_for_day += duration_dict[start_day]
                    duration_dict[start_day] = duration_for_day
                    former_month = current_month
                    print("former status5".format(former_month))
                else:  # if the day is not in the dictionary, add the value
                    duration_dict[start_day] = duration_for_day
                    former_month = current_month
                    print("former status4".format(former_month))

                while True:
                    # go to the next day
                    if current_month == 1 or 3 or 5 or 7 or 8 or 10 or 12:
                        max_day = 31
                    elif current_month == 2:
                        max_day = 28
                    else:
                        max_day = 30

                    if start_day < max_day:
                        start_day += 1
                    else:
                        start_day = 1
                        start_month += 1
                        duration_dict = {}  # clear the records for the month

                    # Update the start date to properly calculate the time period
                    start = start.replace(month=start_month, day=start_day, hour=0, minute=0, second=0)

                    if start_day == end_day:
                        duration = (end - start).total_seconds()  # get the druation in seconds
                        mins = divmod(duration, 60)[0]  # convert duration to minutes
                        duration_for_day = mins
                        duration_dict[start_day] = duration_for_day
                        former_month = current_month
                        print("former status3".format(former_month))
                        break
                    elif start_day != end_day:
                        duration_dict[start_day] = 1440  # this means the device was on the entire day
                        former_month = current_month
                        print("former status2".format(former_month))
        print("former status1".format(former_month))
        if former_month != current_month:
            duration_dict = {}  # clear the records for the month
        duration_by_month[start_month] = duration_dict
    return duration_by_month





def graphbulbPrevious(request):
    import matplotlib.pyplot as plt

    # Get the current usage statistics for the bulb
    bulbStats_current = bulbStats()
    days_mins_dict = {}
    for key, value in bulbStats_current.items():
        days_mins_dict[key] = statsValues(value)

    # Plot all the bar graphs to show the usage statistics for each month
    fig_list = []
    image_list = []
    for key, value in days_mins_dict.items():

        # Determine the month to plot the title and x-axis
        if key == 1:
            month = 'January'
            max_day = 31
        elif key == 2:
            month = 'February'
            max_day = 28
        elif key == 3:
            month = 'March'
            max_day = 31
        elif key == 4:
            month = 'April'
            max_day = 30
        elif key == 5:
            month = 'May'
            max_day = 31
        elif key == 6:
            month = 'June'
            max_day = 30
        elif key == 7:
            month = 'July'
            max_day = 31
        elif key == 8:
            month = 'August'
            max_day = 31
        elif key == 9:
            month = 'September'
            max_day = 30
        elif key == 10:
            month = 'October'
            max_day = 31
        elif key == 11:
            month = 'November'
            max_day = 30
        elif key == 12:
            month = 'December'
            max_day = 31

        # Set the x and y values for the plot
        x = value[0]
        y = value[1]

        # Plot a bar chart of the usage statistics for the current iteration
        fig = plt.figure(figsize=(10,6))  # Instantiate the fig variable to each of the plots

        plt.title(month)
        plt.ylabel('Minutes')
        plt.xlabel('Day of Month')
        plt.xticks(np.arange(0, max_day + 1))
        plt.xlim(0, 32)
        plt.bar(x, y)

        fig_list.append(fig)  # Saves all the plots to a list
        # plt.show()

    buffer1_bulb = BytesIO()  # assign bytes stream value to object referenced as 'buffer' which is kept by Python in memory.
    canvas_image1_bulb = fig_list[0].canvas

    # canvas = plt.get_current_fig_manager().canvas
    canvas_image1_bulb.draw()  # loads the information
    graphIMG1_bulb = Image.frombytes("RGB", canvas_image1_bulb.get_width_height(), canvas_image1_bulb.tostring_rgb())
    graphIMG1_bulb.save(buffer1_bulb, "PNG")
    image_list.append(graphIMG1_bulb.save(buffer1_bulb, "PNG"))
    # plt.close()
    return HttpResponse(buffer1_bulb.getvalue(), content_type="image/png" )



