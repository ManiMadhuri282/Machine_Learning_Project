"""inf551_iot URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from django.contrib import admin

from inf551_iot import bulb
from inf551_iot import views
from inf551_iot import plug
from inf551_iot import speaker
from inf551_iot import StatisticsBulbCurrent
from inf551_iot import StatisticsBulbPrevious
from inf551_iot import StatisticsPlugCurrent
from inf551_iot import StatisticsPlugPrevious
from inf551_iot import StatisticsSpeakerCurrent
from inf551_iot import StatisticsSpeakerPrevious
from django.urls import path

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^htmlBulbC', views.htmlBulbC.as_view(), name='htmlBulbC'),
    url(r'^htmlBulbP', views.htmlBulbP.as_view(), name='htmlBulbP'),
    url(r'^htmlPlugC', views.htmlPlugC.as_view(), name='htmlPlugC'),
    url(r'^htmlPlugP', views.htmlPlugP.as_view(), name='htmlPlugP'),
    url(r'^htmlSpeakerC', views.htmlSpeakerC.as_view(), name='htmlSpeakerC'),
    url(r'^htmlSpeakerP', views.htmlSpeakerP.as_view(), name='htmlSpeakerP'),
    url(r'^speakerApp', views.speakerApp.as_view(), name='speakerApp'),
    url(r'^bulbApp', views.bulbApp.as_view(), name='bulbApp'),
    url(r'^$', views.home, name='home'),
    url(r'^plugStatus', plug.plugStatus, name='plugStatus'),
    url(r'^plugOnOff', plug.plugOnOff, name='plugOnOff'),
    url(r'^plugStats', plug.plugStats, name='plugStats'),
    url(r'^speakerOnOff', speaker.speakerOnOff, name='speakerOnOff'),
    url(r'^speakerPlayStop', speaker.speakerPlayStop, name='speakerPlayStop'),
    url(r'^speakerFwd', speaker.speakerFwd, name='speakerFwd'),
    url(r'^speakerBack', speaker.speakerBack, name='speakerBack'),
    url(r'^speakerStats', speaker.speakerStats, name='speakerStats'),
    url(r'^speakerVolume', speaker.speakerVolume, name='speakerVolume'),
    url('bulb/', bulb.bulb, name='bulb'),
    url(r'^bulbOnOff', bulb.bulbOnOff, name='bulbOnOff'),
    url(r'^postToDimmer/$', bulb.bulbDimmer),
    url(r'^bulbDimmer', bulb.bulbDimmer, name='bulbDimmer'),
    url(r'^bulbStats', bulb.bulbStats, name='bulbStats'),
    url(r'^graphbulbCurrent', StatisticsBulbCurrent.graphbulbCurrent, name='graphbulbCurrent'),
    url(r'^graphbulbPrevious', StatisticsBulbPrevious.graphbulbPrevious, name='graphbulbPrevious'),
    url(r'^graphplugCurrent', StatisticsPlugCurrent.graphplugCurrent, name='graphplugCurrent'),
    url(r'^graphplugPrevious', StatisticsPlugPrevious.graphplugPrevious, name='graphplugPrevious'),
    url(r'^graphspeakerCurrent', StatisticsSpeakerCurrent.graphspeakerCurrent, name='graphspeakerCurrent'),
    url(r'^graphspeakerPrevious', StatisticsSpeakerPrevious.graphspeakerPrevious, name='graphspeakerPrevious'),
    url(r'^graphspeakerStatus', speaker.speakerStatus, name='speakerStatus'),
    url(r'^speaker', speaker.speaker, name='speaker'),
    url(r'^plug', plug.plug, name='plug'),
    url(r'^bulb', bulb.bulb, name='bulb'),


]
