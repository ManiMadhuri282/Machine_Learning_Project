from django.conf.urls import url
from inf551_iot import views

urlpatterns = [
    url(r'^$', views.statistics.as_view(), name='statistics'),

]